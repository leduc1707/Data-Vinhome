---
trang_thai: da-thu-thap-mot-phan
toa: M1
cap_nhat: 2026-09-29
---

# Thông tin tòa M1 — Masteri Waterfront (The Miami)

Tòa tháp căn hộ đại diện thuộc phân khu Miami, dự án Masteri Waterfront (Vinhomes Ocean Park 1).

## Thông số kỹ thuật

| Hạng mục | Giá trị | Nguồn |
|---|---|---|
| Phân khu | Miami (The Miami) | Masterise Homes |
| Đơn vị phát triển | Masterise Homes | Masterise Homes |
| Đơn vị vận hành | Masterise Property Management | Masterise Homes |
| Chiều cao tầng | 26 tầng nổi + 1 tầng hầm | OneHousing, Masterise |
| Phân bổ công năng | Tầng 1: Sảnh đón lễ tân, Business Lobby, Shop thương mại; Tầng 2–25: Căn hộ; Tầng 26: Bể bơi bốn mùa panorama + căn hộ; Tầng thượng: Vườn chân mây | OneHousing, vinhomesland |
| Tổng số căn hộ | Khoảng 517–541 căn | OneHousing, vinhomesland |
| Mật độ căn hộ | 21–22 căn/sàn | OneHousing, Masterise |
| Layout mặt bằng | Hình chữ L | OneHousing 01/2026 |
| Thang máy | 5 thang (4 thang khách + 1 thang hàng); 2 thang bộ thoát hiểm | OneHousing, vinhomesland |
| Loại hình căn hộ | Studio, 1PN+1, 2PN, 2PN+1, 3PN | OneHousing |
| Diện tích căn hộ | 27,1 – 106,8 m² (thông thủy) | OneHousing |
| Bàn giao | Quý 2–3/2023 | Masterise Homes |
| Tiêu chuẩn bàn giao | Hoàn thiện cao cấp liền tường (sàn gỗ, điều hòa âm trần, bếp Hafele, thiết bị vệ sinh Kohler/Grohe) | Masterise Homes |
| Vị trí / Tiếp giáp | Ngã tư đường Hải Đăng và Đại Dương 1 | OneHousing |

## Cơ cấu diện tích các loại căn

- Căn hộ Studio: 27,1 – 35,1 m² (thích hợp cho người độc thân hoặc cho thuê).
- Căn hộ 1PN+1: 41,2 – 48,2 m² (1 phòng ngủ + 1 không gian đa năng).
- Căn hộ 2PN: 54,0 – 64,0 m² (2 phòng ngủ, 1–2 vệ sinh).
- Căn hộ 2PN+1: 60,0 – 70,0 m² (2 phòng ngủ + 1 không gian đa năng).
- Căn hộ 3PN: 74,0 – 106,8 m² (căn góc, view hồ điều hòa Ngọc Trai hoặc công viên nội khu).

## Tiếp giáp ngoại cảnh

- Phía Đông Bắc: Giáp công viên nội khu Miami và sân BBQ, đối diện đường 30m sang The Sapphire 1.
- Phía Đông Nam: Giáp cảnh quan nội khu và tòa M2, hướng tầm nhìn ra hồ Ngọc Trai 24,5 ha.
- Phía Tây Nam: Giáp trục đường Hải Đăng.
- Phía Tây Bắc: Giáp trục đường Đại Dương 1 và phân khu tiện ích.

## Nguồn

- masterisehomes.com — Mặt bằng và tiêu chuẩn bàn giao Masteri Waterfront (tháng 09/2026).
- onehousing.vn — Dữ liệu phân tích mặt bằng và quỹ căn tòa M1 Miami (tháng 09/2026).
- vinhomesland.vn — Bản vẽ layout và hệ thống thang máy tòa M1 (tháng 09/2026).
