---
trang_thai: da-thu-thap-mot-phan
toa: H1
cap_nhat: 2026-09-29
---

# Số điện thoại trực tòa — H1 (The Nomad)

Đầu mối liên hệ trực ca và hỗ trợ cư dân tòa H1 phân khu Hawaii. Đối chiếu bảng niêm yết tại quầy lễ tân sảnh H1 để cập nhật số máy lẻ mới nhất.

## Bảng đầu mối liên hệ

| Nội dung công việc | Nơi tiếp nhận & Đầu mối | Kênh liên hệ |
|---|---|---|
| Hỗ trợ tại sảnh, đón tiếp khách, giao nhận đồ | Quầy Lễ tân sảnh H1 (trực 24/7) | Trực tiếp tại quầy lễ tân tầng 1 tòa H1 (số máy lẻ xem bảng sảnh) |
| An ninh trật tự & điều phối lối hầm H1 | Đội an ninh phân khu Hawaii | Trực tiếp tại chốt sảnh & lối hầm H1 |
| **Hotline Ban Quản lý Masteri Waterfront** | Ban Quản lý dự án | **0818 910 909** hoặc **0888 366 159** (theo số máy lẻ) |
| Điều phối xe buggy ra nhà xe nổi (6h–22h) | Đội xe buggy Masterise Homes | Hotline BQL **0818 910 909** hoặc qua Lễ tân sảnh H1 |
| Yêu cầu kỹ thuật, bảo trì, sửa chữa căn hộ | Đội kỹ thuật Masterise Property Management | Tạo ticket trên ứng dụng Masterise Homes (chọn tòa H1) |
| Đăng ký thẻ xe, thanh toán phí, hồ sơ thi công | Văn phòng Ban Quản lý Masterise (khối đế) | Trực tiếp giờ hành chính (8h30–17h30 T2–T7) |
| Hòm thư điện tử tiếp nhận khiếu nại | Bộ phận CSKH Masterise Homes | cskh@masterisehomes.com |
| Tình huống khẩn cấp quốc gia | Cảnh sát PCCC / Y tế / Công an | **114 / 115 / 113** |

## Định danh tòa trên hệ thống

- Tên hiển thị trên ứng dụng Masterise Homes: Tòa H1 - Phân khu Hawaii - Masteri Waterfront.
- Không sử dụng ứng dụng Vinhomes Resident để tra cứu thông tin hay tạo phiếu cho tòa H1.

## Nguồn

- Thông báo chính thức của Ban Quản lý Masteri Waterfront / Kênh "Nhà tôi ở Masterise" (21/11/2024).
- masterisehomes.com — Kênh liên hệ chính thức Masterise Homes & Masterise Property Management (tháng 09/2026).
- Bảng thông tin niêm yết tại quầy Lễ tân sảnh H1.
