---
trang_thai: da-thu-thap-mot-phan
toa: M1
cap_nhat: 2026-09-29
---

# Số điện thoại trực tòa — M1 (The Miami)

Đầu mối liên hệ trực ca và hỗ trợ cư dân tòa M1. Số máy lẻ của quầy lễ tân sảnh M1 cần đối chiếu bảng niêm yết tại sảnh trước khi lưu chính thức.

## Bảng đầu mối liên hệ

| Nội dung công việc | Nơi tiếp nhận & Đầu mối | Kênh liên hệ |
|---|---|---|
| Hỗ trợ tại sảnh, đón khách, nhận bưu kiện | Quầy Lễ tân sảnh M1 (trực 24/7) | Trực tiếp tại quầy lễ tân tầng 1 tòa M1 (số máy lẻ xem bảng sảnh) |
| An ninh tòa nhà & điều phối hầm xe | Đội an ninh phân khu Miami | Trực tiếp tại chốt sảnh & lối hầm M1 |
| **Hotline Ban Quản lý Masteri Waterfront** | Ban Quản lý dự án | **0818 910 909** hoặc **0888 366 159** (theo số máy lẻ) |
| Điều phối xe buggy ra nhà xe nổi (6h–22h) | Đội xe buggy Masterise Homes | Hotline BQL **0818 910 909** hoặc qua Lễ tân sảnh M1 |
| Yêu cầu kỹ thuật, báo hỏng hóc trong căn | Đội kỹ thuật Masterise Property Management | Tạo ticket trên ứng dụng Masterise Homes (chọn tòa M1) |
| Đăng ký thẻ xe, đóng phí, thủ tục thi công | Văn phòng Ban Quản lý Masterise (khối đế) | Trực tiếp giờ hành chính (8h30–17h30 T2–T7) |
| Hòm thư điện tử tiếp nhận khiếu nại | Bộ phận CSKH Masterise Homes | cskh@masterisehomes.com |
| Tình huống khẩn cấp quốc gia | Cảnh sát PCCC / Y tế / Công an | **114 / 115 / 113** |

## Định danh tòa trên hệ thống

- Tên hiển thị trên ứng dụng Masterise Homes: Tòa M1 - Phân khu Miami - Masteri Waterfront.
- Không dùng ứng dụng Vinhomes Resident để tra cứu thông tin tòa M1.

## Nguồn

- Thông báo chính thức của Ban Quản lý Masteri Waterfront / Kênh "Nhà tôi ở Masterise" (21/11/2024).
- masterisehomes.com — Kênh liên hệ chính thức Masterise Homes & Masterise Property Management (tháng 09/2026).
- Bảng thông tin niêm yết tại quầy Lễ tân sảnh M1.
