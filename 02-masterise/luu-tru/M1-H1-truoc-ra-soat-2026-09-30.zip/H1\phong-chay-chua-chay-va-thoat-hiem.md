---
trang_thai: da-thu-thap-mot-phan
toa: H1
cap_nhat: 2026-09-29
---

# Phòng cháy chữa cháy và thoát hiểm — H1 (The Nomad)

Chưa có bản scan sơ đồ thoát nạn chính thức. Dưới đây là hiện vật và thông số kỹ thuật tòa H1 phân khu Hawaii đã được đối chiếu qua hồ sơ công khai.

## Hiện vật tòa H1

- Chiều cao: 27 tầng nổi + 1 tầng hầm để xe (liên thông toàn phân khu Hawaii H1, H2, H3).
- Công năng từng tầng:
  - Tầng 1: Sảnh đón tiếp Lễ tân, Business Lobby, phòng sinh hoạt cộng đồng, shop chân đế thương mại.
  - Tầng 2–26: Căn hộ cao cấp.
  - Tầng 27: Bể bơi bốn mùa trong nhà tầm nhìn panorama hướng hồ Ngọc Trai và một phần căn hộ.
  - Tầng thượng: Vườn chân mây (Rooftop Garden).
- Layout mặt bằng: Hình chữ L, mật độ 22 căn/sàn, tổng số khoảng 563 căn hộ.
- Hệ thống thang: 5 thang máy (4 thang khách + 1 thang chở hàng/cứu nạn) và 2 buồng thang bộ thoát hiểm có hệ thống quạt tăng áp ngăn khói.
- Quy tắc thoát hiểm: Khi chuông báo cháy reo hoặc có thông báo khẩn cấp, cư dân lập tức di chuyển theo đèn exit vào 2 buồng thang bộ thoát hiểm để xuống tầng 1 ra ngoài. Tuyệt đối KHÔNG sử dụng 5 cabin thang máy.

## Vị trí tòa và lối tiếp cận của lực lượng chữa cháy

- Tòa H1 tọa lạc tại vị trí giao lộ giữa đường Hải Đăng 1 và Hải Đăng 8 trong phân khu Hawaii:
  - Phía Đông Bắc: Hướng tầm nhìn về đường Hải Đăng 8 và công viên Botanic Garden.
  - Phía Đông Nam: Tiếp giáp trục đường Hải Đăng 1, hướng nhìn trực diện ra hồ điều hòa Ngọc Trai 24,5 ha và khu biệt thự thấp tầng.
  - Phía Tây Nam: Tiếp giáp nội khu Hawaii và tòa H2.
  - Phía Tây Bắc: Hướng nhìn về tuyến phố thương mại Malibu Walk và cụm phân khu Miami.
- Xe chữa cháy chuyên dụng tiếp cận tòa nhà thuận lợi từ trục đường Hải Đăng 1 và Hải Đăng 8.
- Tuyệt đối không dừng đỗ phương tiện chắn lối xe chữa cháy, họng tiếp nước PCCC và sảnh đón tầng 1 của tòa H1.

## Việc còn thiếu cần bổ sung khi có hồ sơ thực tế

- Bản scan sơ đồ thoát hiểm chi tiết từng tầng của tòa H1.
- Vị trí cụ thể của các họng nước tiếp cứu hỏa D100 và điểm tập kết cứu nạn ngoài trời theo thiết kế.

## Nguồn

- masteriwaterfrontoceanpark.com — Thông số kỹ thuật và mặt bằng tòa H1 Hawaii (tháng 09/2026).
- onehousing.vn — Mặt bằng thiết kế chi tiết tòa H1 (The Nomad) Masteri Waterfront (tháng 09/2026).
- masterisehomes.com — Hồ sơ tiện ích và bàn giao tòa H1 phân khu Hawaii (tháng 09/2026).
