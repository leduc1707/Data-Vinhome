---
trang_thai: da-thu-thap-mot-phan
toa: H1
cap_nhat: 2026-09-29
---

# Sơ đồ hầm gửi xe — H1 (The Nomad)

Chưa có bản vẽ kỹ thuật chi tiết mặt bằng hầm. Dưới đây là thông số và hiện vật vận hành hầm xe liên quan đến tòa H1 phân khu Hawaii.

## Hiện vật hầm xe tòa H1

- Tầng hầm phân khu Hawaii: Có 1 tầng hầm để xe quy mô lớn liên thông toàn bộ 3 tòa tháp H1, H2 và H3.
- Hệ thống kiểm soát: Thẻ từ cư dân kết hợp camera nhận diện biển số xe thông minh tại các luồng ra vào hầm từ trục đường nội khu Hải Đăng 1 và Hải Đăng 8.
- Phân luồng phương tiện:
  - Khu vực đỗ xe ô tô cư dân có phân chia line rõ ràng và đánh số thứ tự.
  - Khu vực đỗ xe máy, xe máy điện phân theo cụm tòa H1.
  - Khu vực trạm sạc xe điện chuyên dụng, trang bị hệ thống chữa cháy và giám sát nhiệt độ tự động.
- **Tiện ích xe buggy đưa đón nhà xe nổi**: Cư dân tòa H1 khi gửi xe tại các nhà để xe nổi 5 tầng của đại đô thị được phục vụ tuyến xe điện buggy đưa đón 2 chiều (hoạt động từ **6h00 đến 22h00** hàng ngày, ưu tiên hỗ trợ trường hợp khẩn cấp). Hotline điều phối: **0818 910 909**.

## Biểu phí gửi xe tháng tham khảo

- Ô tô: Khoảng 1.250.000 – 1.400.000 đồng/xe/tháng.
- Xe máy / xe máy điện: Khoảng 45.000 – 100.000 đồng/xe/tháng.
- Xe đạp / xe đạp điện: Khoảng 25.000 đồng/xe/tháng.
- Sạc xe điện: Áp dụng đơn giá tính theo công tơ hoặc gói dịch vụ do đơn vị vận hành trạm sạc công bố.
- Thủ tục đăng ký vé tháng: Cư dân nộp bản chụp đăng ký xe (cà vẹt), CCCD qua ứng dụng Masterise Homes hoặc trực tiếp tại văn phòng BQL Masterise.

## Quy tắc an toàn và trật tự tầng hầm

- Tốc độ di chuyển tối đa trong hầm: 5 km/h. Bật đèn chiếu gần (cốt), không bấm còi, chú ý gương cầu lồi tại các khúc cua ram dốc.
- Nghiêm cấm hút thuốc, dùng nguồn nhiệt, rửa xe hoặc sửa chữa phương tiện trong tầng hầm.
- Không tự ý kéo dây cắm điện từ hệ thống chiếu sáng công cộng để sạc xe điện.

## Việc còn thiếu cần bổ sung khi có hồ sơ thực tế

- File PDF bản vẽ mặt bằng phân luồng đỗ xe tầng hầm phân khu Hawaii (khu vực dưới chân tòa H1).
- Sơ đồ chi tiết vị trí các điểm sạc điện và số chỗ đỗ ô tô định danh.

## Nguồn

- Thông báo chính thức của Ban Quản lý Masteri Waterfront / Kênh "Nhà tôi ở Masterise" về dịch vụ xe buggy (21/11/2024).
- masteriwaterfrontoceanpark.com — Thông tin thiết kế hầm liên thông phân khu Hawaii (tháng 09/2026).
- onehousing.vn — Dữ liệu hầm gửi xe và chính sách đỗ xe Masteri Waterfront (tháng 09/2026).
