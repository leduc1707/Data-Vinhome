---
trang_thai: da-thu-thap-mot-phan
toa: H1
cap_nhat: 2026-09-29
---

# Thông tin tòa H1 — Masteri Waterfront (The Nomad - Hawaii)

Tòa tháp căn hộ đại diện thuộc phân khu Hawaii, dự án Masteri Waterfront (Vinhomes Ocean Park 1).

## Thông số kỹ thuật

| Hạng mục | Giá trị | Nguồn |
|---|---|---|
| Phân khu | Hawaii (The Hawaii) | Masterise Homes |
| Đơn vị phát triển | Masterise Homes | Masterise Homes |
| Đơn vị vận hành | Masterise Property Management | Masterise Homes |
| Chiều cao tầng | 27 tầng nổi + 1 tầng hầm | OneHousing, Masterise |
| Phân bổ công năng | Tầng 1: Sảnh lễ tân, Business Lobby, Shop thương mại; Tầng 2–26: Căn hộ; Tầng 27: Bể bơi bốn mùa panorama + căn hộ; Tầng thượng: Vườn chân mây | OneHousing, Masterise |
| Tổng số căn hộ | Khoảng 563 căn | OneHousing, Masterise |
| Mật độ căn hộ | Khoảng 21–22 căn/sàn | OneHousing, Masterise |
| Layout mặt bằng | Hình chữ L | OneHousing |
| Thang máy | 5 thang (4 thang khách + 1 thang hàng); 2 thang bộ thoát hiểm | OneHousing, vinhomesland |
| Loại hình căn hộ | Studio, 1PN+1, 2PN, 2PN+1, 3PN | OneHousing |
| Diện tích căn hộ | 27,0 – 75,0 m² (căn tiêu chuẩn); có căn ghép thông lớn | OneHousing |
| Bàn giao | Năm 2024 | Masterise Homes |
| Tiêu chuẩn bàn giao | Hoàn thiện cao cấp liền tường (kính Low-E, sàn gỗ, điều hòa âm trần, thiết bị bếp và vệ sinh chuẩn quốc tế) | Masterise Homes |
| Vị trí / Tiếp giáp | Giao lộ đường Hải Đăng 1 và Hải Đăng 8 | OneHousing |

## Cơ cấu loại hình và trục căn tiêu biểu

- Căn Studio: 27 – 35 m².
- Căn 1PN+1: Khoảng 41 – 48 m².
- Căn 2PN và 2PN+1: Khoảng 54 – 68 m² (các căn góc tiêu biểu: CH05A, CH08, CH09, CH18).
- Căn 3PN: Khoảng 74 – 75 m² trở lên (các căn góc tiêu biểu: CH05, CH11, CH18A).

## Hướng nhìn (View) ngoại cảnh

- Phía Đông Bắc: Hướng nhìn đường Hải Đăng 8, công viên Botanic Garden và khu shop thương mại Malibu Walk.
- Phía Đông Nam: Tiếp giáp đường Hải Đăng 1, nhìn trực diện hồ điều hòa Ngọc Trai 24,5 ha và cụm biệt thự thấp tầng.
- Phía Tây Nam: Giáp nội khu phân khu Hawaii và tòa H2.
- Phía Tây Bắc: Hướng tầm nhìn về khu phố đi bộ thương mại Malibu Walk và cụm tòa Miami.

## Nguồn

- masterisehomes.com — Hồ sơ thông tin và tiến độ bàn giao phân khu Hawaii (tháng 09/2026).
- onehousing.vn — Mặt bằng tầng, trục căn hộ và hướng view tòa H1 The Nomad (tháng 09/2026).
- vinhomesland.vn — Bản vẽ kiến trúc và hệ thống tiện ích nội khu Hawaii (tháng 09/2026).
