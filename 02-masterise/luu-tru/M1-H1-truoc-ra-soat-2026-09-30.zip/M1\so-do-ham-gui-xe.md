---
trang_thai: da-thu-thap-mot-phan
toa: M1
cap_nhat: 2026-09-29
---

# Sơ đồ hầm gửi xe — M1 (The Miami)

Chưa có bản vẽ kỹ thuật chi tiết mặt bằng hầm. Dưới đây là thông số và hiện vật vận hành hầm xe liên quan đến tòa M1.

## Hiện vật hầm xe tòa M1

- Tầng hầm phân khu Miami: Có 1 tầng hầm để xe quy mô lớn liên thông toàn bộ 3 tòa tháp M1, M2 và M3.
- Hệ thống kiểm soát: Sử dụng thẻ từ cư dân kết hợp camera nhận diện biển số xe thông minh tại các làn vào/ra tầng hầm.
- Phân luồng phương tiện:
  - Khu vực đỗ xe ô tô cư dân có kẻ vạch phân chia rõ ràng.
  - Khu vực đỗ xe máy, xe máy điện có phân chia khu vực theo từng cụm tòa.
  - Khu vực trạm sạc xe điện tập trung, trang bị hệ thống PCCC tự động chuyên dụng.
- **Tiện ích xe buggy đưa đón nhà xe nổi**: Cư dân phân khu Miami gửi xe tại nhà xe nổi 5 tầng của đại đô thị được phục vụ tuyến xe điện buggy đưa đón 2 chiều (hoạt động từ **6h00 đến 22h00** hàng ngày, ưu tiên hỗ trợ trường hợp khẩn cấp). Hotline điều phối: **0818 910 909**.

## Biểu phí gửi xe tháng tham khảo

- Ô tô: Khoảng 1.250.000 – 1.400.000 đồng/xe/tháng.
- Xe máy / xe máy điện: Khoảng 45.000 – 100.000 đồng/xe/tháng.
- Xe đạp / xe đạp điện: Khoảng 25.000 đồng/xe/tháng.
- Sạc xe điện: Áp dụng đơn giá tính theo công tơ hoặc gói dịch vụ do đơn vị vận hành trạm sạc công bố.
- Thủ tục đăng ký vé tháng: Cư dân chụp ảnh đăng ký xe (cà vẹt), CCCD nộp qua ứng dụng Masterise Homes hoặc đăng ký trực tiếp tại văn phòng BQL Masterise.

## Quy tắc an toàn và trật tự tầng hầm

- Tốc độ di chuyển tối đa trong hầm: 5 km/h. Bật đèn cốt (chiếu gần), tuân thủ gương cầu lồi và biển báo phân luồng.
- Nghiêm cấm hút thuốc, dùng nguồn lửa trần, rửa xe hoặc sửa chữa động cơ trong tầng hầm.
- Nghiêm cấm tự ý câu kéo dây điện từ các tủ điện/ổ cắm chiếu sáng công cộng để sạc xe điện cá nhân.

## Việc còn thiếu cần bổ sung khi có hồ sơ thực tế

- File PDF bản vẽ mặt bằng phân luồng đỗ xe tầng hầm cụm Miami (vị trí khu vực hầm dưới chân tòa M1).
- Sơ đồ mã số từng vị trí đỗ ô tô và trạm sạc điện.

## Nguồn

- Thông báo chính thức của Ban Quản lý Masteri Waterfront / Kênh "Nhà tôi ở Masterise" về dịch vụ xe buggy (21/11/2024).
- masteriwaterfrontoceanpark.com — Thông tin thiết kế hầm liên thông phân khu Miami (tháng 09/2026).
- onehousing.vn — Hướng dẫn gửi xe và biểu phí Masteri Waterfront (tháng 09/2026).
