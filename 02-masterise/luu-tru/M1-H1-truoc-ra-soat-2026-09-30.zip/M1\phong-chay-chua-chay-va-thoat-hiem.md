---
trang_thai: da-thu-thap-mot-phan
toa: M1
cap_nhat: 2026-09-29
---

# Phòng cháy chữa cháy và thoát hiểm — M1 (The Miami)

Chưa có bản scan sơ đồ thoát nạn chính thức. Dưới đây là hiện vật và thông số kỹ thuật tòa M1 đã được đối chiếu qua hồ sơ công khai.

## Hiện vật tòa M1

- Chiều cao: 26 tầng nổi + 1 tầng hầm để xe (liên thông toàn phân khu Miami).
- Công năng từng tầng:
  - Tầng 1: Sảnh đón tiếp Lễ tân, Business Lobby, phòng quản lý, shop chân đế thương mại.
  - Tầng 2–25: Căn hộ cao cấp.
  - Tầng 26: Bể bơi bốn mùa trong nhà tầm nhìn panorama và một phần căn hộ.
  - Tầng thượng: Vườn chân mây (Rooftop Garden).
- Layout mặt bằng: Hình chữ L, mật độ 21–22 căn/sàn, tổng số khoảng 517–541 căn hộ.
- Hệ thống thang: 5 thang máy hiện đại (4 thang khách + 1 thang chở hàng/cứu hỏa) và 2 buồng thang bộ thoát hiểm có hệ thống tạo áp suất dương ngăn khói.
- Quy tắc thoát hiểm: Khi có báo động cháy khẩn cấp, tuyệt đối không dùng 5 cabin thang máy; cư dân di chuyển nhanh chóng vào 2 buồng thang bộ thoát hiểm có đèn chỉ dẫn Exit để xuống tầng 1 thoát ra ngoài.

## Vị trí tòa và lối tiếp cận của lực lượng chữa cháy

- Tòa M1 nằm ở góc phía Tây Bắc của phân khu Miami:
  - Phía Đông Bắc: Tiếp giáp tuyến đường nội khu 30m, đối diện cụm tòa phân khu The Sapphire 1.
  - Phía Đông Nam: Tiếp giáp tiện ích nội khu cụm Miami và tòa M2, hướng tầm nhìn về hồ điều hòa Ngọc Trai 24,5 ha.
  - Phía Tây Bắc: Tiếp giáp trục đường Hải Đăng và công viên nội khu.
  - Phía Tây Nam: Tiếp giáp khu vực cảnh quan nội khu Miami.
- Xe chữa cháy chuyên dụng của Cảnh sát PCCC tiếp cận từ trục đường Hải Đăng và đường phân khu 30m.
- Nghiêm cấm dừng đỗ phương tiện chắn lối xe chữa cháy, sảnh đón trả khách M1 và trụ tiếp nước chữa cháy vách tường.

## Việc còn thiếu cần bổ sung khi có hồ sơ thực tế

- Bản scan sơ đồ mặt bằng thoát nạn chi tiết từng tầng (tầng 1, tầng căn hộ, tầng 26 bể bơi, tầng hầm).
- Tọa độ bảng niêm yết điểm tập kết cứu nạn ngoài nhà.
- Vị trí cụ thể các trụ nước chữa cháy ngoài trời và họng tiếp nước D100 của tòa nhà.

## Nguồn

- masteriwaterfrontoceanpark.com — Mặt bằng thiết kế và tiện ích tòa M1 Miami (tháng 09/2026).
- onehousing.vn — Thông số kỹ thuật tòa M1 Masteri Waterfront (tháng 09/2026).
- vinhomesland.vn — Chi tiết layout hình chữ L và phân bố tầng tòa M1 (tháng 09/2026).
